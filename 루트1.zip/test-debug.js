// test-debug.js - 디버깅용 테스트 스크립트
const fetch = require('node-fetch');

async function testPatentSearch() {
    console.log('🔍 특허 검색 테스트 시작...');
    
    const testCustomerNumber = '120190612244'; // 테스트용 고객번호
    
    try {
        // 1. 기본 특허 검색 테스트
        console.log('\n📋 1단계: 기본 특허 검색');
        const searchResponse = await fetch('http://localhost:3000/api/search-registered', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ customerNumber: testCustomerNumber })
        });
        
        const searchResult = await searchResponse.json();
        console.log('✅ 검색 결과:', {
            success: searchResult.success,
            totalCount: searchResult.totalCount,
            method: searchResult.crawlingMethod
        });
        
        if (searchResult.patents && searchResult.patents.length > 0) {
            const firstPatent = searchResult.patents[0];
            console.log('\n📊 첫 번째 특허 데이터:', {
                applicationNumber: firstPatent.applicationNumber,
                registrationNumber: firstPatent.registrationNumber,
                applicantName: firstPatent.applicantName,
                claimCount: firstPatent.claimCount,
                expirationDate: firstPatent.expirationDate,
                validityStatus: firstPatent.validityStatus,
                currentAnnualInfo: firstPatent.currentAnnualInfo,
                previousAnnualInfo: firstPatent.previousAnnualInfo
            });
            
            // 2. 상세정보 크롤링 테스트 (등록번호가 있는 경우)
            if (firstPatent.registrationNumber && firstPatent.registrationNumber !== '-') {
                console.log('\n📋 2단계: 상세정보 크롤링 테스트');
                console.log('등록번호:', firstPatent.registrationNumber);
                
                try {
                    const detailResponse = await fetch('http://localhost:3000/api/crawl-patent-details', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ registrationNumber: firstPatent.registrationNumber })
                    });
                    
                    const detailResult = await detailResponse.json();
                    console.log('✅ 상세정보 크롤링 결과:', {
                        success: detailResult.success,
                        registrationStatus: detailResult.patentDetails?.registrationStatus,
                        claimCount: detailResult.patentDetails?.claimCount,
                        expirationDate: detailResult.patentDetails?.expirationDate,
                        validityStatus: detailResult.patentDetails?.validityStatus,
                        currentAnnualInfo: detailResult.patentDetails?.currentAnnualInfo,
                        previousAnnualInfo: detailResult.patentDetails?.previousAnnualInfo
                    });
                    
                } catch (detailError) {
                    console.error('❌ 상세정보 크롤링 오류:', detailError.message);
                }
            } else {
                console.log('⚠️ 등록번호가 없어 상세정보 크롤링 생략');
            }
        }
        
    } catch (error) {
        console.error('❌ 테스트 오류:', error.message);
    }
}

// 테스트 실행
if (require.main === module) {
    testPatentSearch().then(() => {
        console.log('\n🎯 테스트 완료');
        process.exit(0);
    }).catch((error) => {
        console.error('💥 테스트 실패:', error);
        process.exit(1);
    });
}