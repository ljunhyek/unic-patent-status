// ⚠️ 더 이상 사용되지 않음: KIPRIS API 테스트 파일 (크롤링 기반으로 전환)
// 이 파일은 참고용으로만 보관됨
/*
require('dotenv').config();
const axios = require('axios');

async function testKiprisAPI() {
    const customerNumber = '120010054571';
    const apiKey = process.env.KIPRIS_API_KEY;
    const baseUrl = process.env.KIPRIS_API_BASE_URL || 'http://plus.kipris.or.kr/kipo-api/kipicom';
    
    console.log('🔧 테스트 설정:', {
        customerNumber,
        baseUrl,
        hasApiKey: !!apiKey
    });
    
    try {
        const url = `${baseUrl}/patUtiModInfoSearchSevice/getWordSearch`;
        
        console.log('🌐 API 호출:', url);
        
        const response = await axios.get(url, {
            params: {
                word: customerNumber,
                ServiceKey: apiKey,
                numOfRows: 100, // 한 번에 최대 100개까지 요청
                pageNo: 1
            },
            timeout: 10000
        });
        
        console.log('📡 응답 상태:', response.status);
        console.log('📊 응답 크기:', JSON.stringify(response.data).length, 'bytes');
        console.log('📄 응답 내용:', JSON.stringify(response.data, null, 2));
        
    } catch (error) {
        console.error('❌ API 호출 오류:', error.message);
        if (error.response) {
            console.error('📡 오류 응답 상태:', error.response.status);
            console.error('📄 오류 응답 내용:', error.response.data);
        }
    }
}

testKiprisAPI();
*/